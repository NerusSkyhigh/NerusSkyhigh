# progetto_apollo
In this repository I'm going to upload all the text and speech I'll do for the Scientific Theater group "Progetto Apollo"
