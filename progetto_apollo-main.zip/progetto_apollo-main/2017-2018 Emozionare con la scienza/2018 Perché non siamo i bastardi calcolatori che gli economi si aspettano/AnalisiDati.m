close all;
[old_nickname, old_risposta1, old_risposta2] = importfile('[TEST] Gioco interattivo_cumulativo.csv');
[new_nickname, new_risposta1, new_risposta2] = importfile('[TEST] Gioco interattivo.csv');

nickname = [old_nickname; new_nickname];
risposta1 = [old_risposta1; new_risposta1];
risposta2 = [old_risposta2; new_risposta2];

clear new_nickname new_risposta1 new_risposta2 old_nickname old_risposta1 old_risposta2;

%% Mi occupo di disegnare l'istogramma della prima risposta
% i bin sono la suddivisione dell'asse x dell'istogramma
bin = 0 : 10 : 100;

% Dico a matlab di contarmi le occorrenze dei dati in ogni bin
occorrenze = histcounts(risposta1, bin);

% Creo una nuova finestra e una nuova variabile istogramma
    finestra_istogramma = figure();
    istogramma = histogram(risposta1, bin);
% adesso accedo agli assi per lavorarci. Nota che vengono restituiti gli assi dell'oggetto corrente
    assi_istogramma = gca();
% imposto gli assi dell'istogramma e il titolo e li personalizzo
    set(assi_istogramma, 'NextPlot', 'add');
    asse_y_istogramma = ylabel('Occorrenze');
        set(asse_y_istogramma, 'FontSize', 24);
    asse_x_istogramma = xlabel('Numero Scelto');
        set(asse_x_istogramma, 'FontSize', 24);
    
% creo un nuovo titolo. Con strrep(str,old,new) sostiuisco da str la substringa old con la stringa new 
    titolo_istogramma = title('Distribuzione delle risposte');
    set(titolo_istogramma, 'fontsize', 24);

	hold on;

%% Adesso analizzo i dati
	vincitore = 2/3*mean(risposta1);
	[c index_vincitore] = min( abs( risposta1-vincitore ) );
	username_vincitore = nickname(index_vincitore);
	y = [0:0.1:max(occorrenze)]; 
	x = vincitore*ones( size(y) );
	retta = plot(x,y, 'LineWidth',2, 'MarkerSize',10);
	
% E infine aggiungo una legenda
    legenda = legend('Distribuzione delle risposte', strcat('Vincitore (', num2str(vincitore), ',', username_vincitore, ')'));
    set(legenda, 'FontSize', 10, 'Location', 'NorthEast');

hold off;

%% Ed ora l'analogo per la risposta 2

% i bin sono la suddivisione dell'asse x dell'istogramma
bin = -0.5 : 1 : 10.5;
% sanitizzo l'input eliminando i -1
risposta2 = risposta2(risposta2>=0);


% Dico a matlab di contarmi le occorrenze dei dati in ogni bin
occorrenze = histcounts(risposta2, bin);

% Creo una nuova finestra e una nuova variabile istogramma
    finestra_istogramma = figure();
    istogramma = histogram(risposta2, bin);
% adesso accedo agli assi per lavorarci. Nota che vengono restituiti gli assi dell'oggetto corrente
    assi_istogramma = gca();
% imposto gli assi dell'istogramma e il titolo e li personalizzo
    set(assi_istogramma, 'NextPlot', 'add');
    asse_y_istogramma = ylabel('Occorrenze');
        set(asse_y_istogramma, 'FontSize', 24);
    asse_x_istogramma = xlabel('Numero Scelto');
        set(asse_x_istogramma, 'FontSize', 24);
    
% creo un nuovo titolo. Con strrep(str,old,new) sostiuisco da str la substringa old con la stringa new 
    titolo_istogramma = title('Soldi donati');
    set(titolo_istogramma, 'fontsize', 24);

	hold on;
	
% E infine aggiungo una legenda
%    legenda = legend('Distribuzione delle risposte', strcat('Vincitore (', num2str(vincitore), ')'));
%    set(legenda, 'FontSize', 10, 'Location', 'NorthEast');

hold off;